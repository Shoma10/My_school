#include "s21_string.h"

#include <stdio.h>
#include <stdlib.h>

void s21_strlen_test();
void s21_strcmp_test();
void s21_strcpy_test();
void s21_strcat_test();
void s21_strchr_test();

int main() {
#ifdef STRLEN
    s21_strlen_test();
#endif

#ifdef STRCMP
    s21_strcmp_test();
#endif

#ifdef STRCPY
    s21_strcpy_test();
#endif

#ifdef STRCAT
    s21_strcat_test();
#endif

#ifdef STRCHR
    s21_strchr_test();
#endif
}

void s21_strlen_test() {
    char *str0 = "hello";
    char *str1 = "h e l l o\n h e l l o\t";
    char *str2 = "\t";
    char *str3 = "";
    printf("%s %s %s %s\n", str0, str1, str2, str3);
    printf("%d %d %d %d\n", s21_strlen(str0), s21_strlen(str1), s21_strlen(str2), s21_strlen(str3));
    if (s21_strlen(str0) == 5)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    if (s21_strlen(str1) == 21)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    if (s21_strlen(str2) == 1)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    if (s21_strlen(str2) == 1)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
}

void s21_strcmp_test() {
    char *str1 = "12345";
    char *str2 = "12346";
    char *str3 = "1a345";
    printf("\n%s %s %s\n", str1, str2, str3);
    printf("%d %d %d\n", s21_strcmp(str1, str2), s21_strcmp(str1, str3), s21_strcmp(str3, str2));
    if (s21_strcmp(str1, str2) == -1)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    if (s21_strcmp(str1, str3) == -47)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
    if (s21_strcmp(str3, str2) == 47)
        printf("SUCCESS\n");
    else
        printf("FAIL\n");
}

void s21_strcpy_test() {
    char string1[1024] = "ABCDE";
    char string2[1024] = "fddddddd";
    char string3[1024] = "12hg34";
    char string4[1024] = "123456";
    char string5[1024] = "Hello world";
    char string6[1024] = "Hello person";
    printf("\n%s %s %s %s %s %s\n", string1, string2, string3, string4, string5, string6);
    s21_strcpy(string1, string2);
    printf("\n%s %s\n", string1, string2);

    s21_strcpy(string4, string3);
    printf("\n%s %s\n", string4, string3);

    s21_strcpy(string5, string6);
    printf("\n%s %s\n", string5, string6);
    printf("%d %d %d\n", s21_strcmp(string1, string2), s21_strcmp(string4, string3),
           s21_strcmp(string5, string6));
    printf(s21_strcmp(string1, string2) == 0 ? "SUCCESS" : "FAIL");
    printf(s21_strcmp(string4, string3) == 0 ? " SUCCESS" : "FAIL");
    printf(s21_strcmp(string5, string6) == 0 ? " SUCCESS" : "FAIL");
}

void s21_strcat_test() {
    char string1[1024] = "ABCDE";
    char string2[1024] = "fddddddd";
    char string3[1024] = "Hello";
    char string4[1024] = " world";
    char string5[1024] = "Love";
    char string6[1024] = " is";
    printf("\n\n%s %s\n", string1, string2);
    s21_strcat(string1, string2);
    printf("%s\n", string1);
    printf(s21_strcmp(string1, "ABCDEfddddddd") == 0 ? "SUCCESS" : "FAIL");
    printf("\n%s%s\n", string3, string4);
    s21_strcat(string3, string4);
    printf("%s\n", string3);
    printf(s21_strcmp(string3, "Hello world") == 0 ? "SUCCESS" : "FAIL");
    printf("\n%s%s\n", string5, string6);
    s21_strcat(string5, string6);
    printf("%s\n", string5);
    printf(s21_strcmp(string5, "Love is") == 0 ? "SUCCESS" : "FAIL");
}

void s21_strchr_test() {
    const char *str1 = "Hello, world!";
    const char *res = s21_strchr(str1, 'o');
    printf("%s %c\n", str1, 'o');
    printf("%s\n", res);
    if (s21_strlen(res) != s21_strlen(str1) - 4) {
        printf("FAIL\n");
    } else {
        printf("SUCCESS\n");
    }

    const char *str2 = "Unbelievable";
    const char *res2 = s21_strchr(str2, 'o');
    printf("\n%s %c\n", str2, 'o');
    printf("%s\n", res2);
    if (res2 == NULL) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }

    const char *str3 = "\t";
    const char *res3 = s21_strchr(str3, 'o');
    printf("\n%s %c\n", str3, 'o');
    printf("%s\n", res3);
    if (res2 == NULL) {
        printf("SUCCESS\n");
    } else {
        printf("FAIL\n");
    }
}
