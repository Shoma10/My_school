#include "./s21_string.h"

#include <stdlib.h>

int s21_strlen(const char *str) {
    int length = 0;
    while (*(str + length)) length++;
    return length;
}

int s21_strcmp(const char *str1, const char *str2) {
    for (; *str1 && *str1 == *str2; str1++, str2++)
        ;
    return *str1 - *str2;
}

char *s21_strcpy(char *dest, const char *src) {
    while (*src != '\0') {
        *dest++ = *src++;
    }
    *dest = '\0';
    return dest;
}

char *s21_strcat(char *dest, const char *src) {
    char *dest_start = dest;
    while (*dest != '\0') {
        dest++;
    }
    while ((*dest++ = *src++) != '\0')
        ;
    return dest_start;
}

char *s21_strchr(const char *s, int c) {
    while (*s != '\0') {
        if (*s == c) {
            return (char *)s;
        }
        s++;
    }
    if (c == '\0') {
        return (char *)s;
    }
    return NULL;
}
