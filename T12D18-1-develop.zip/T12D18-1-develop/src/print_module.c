#include "print_module.h"

#include <stdio.h>
#include <string.h>
#include <time.h>

char print_char(char ch) { return putchar(ch); }

void print_log(char (*print)(char), char* message) {
    char s[40];
    struct tm* u;
    time_t timer = time(NULL);
    u = localtime(&timer);
    strftime(s, 40, "%H:%M:%S", u);
    for (int i = 0; i < (int)strlen(Log_prefix); i++) {
        print(Log_prefix[i]);
    }
    print(' ');
    for (int i = 0; s[i] != '\0'; i++) print(s[i]);
    print(' ');
    for (int i = 0; i < (int)strlen(message); i++) print(message[i]);
}
