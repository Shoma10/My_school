#include <stdio.h>
int main() {
  char *a;
  a = "Hello, AI!";
  { printf("%s", a); }
  return 0;
}
