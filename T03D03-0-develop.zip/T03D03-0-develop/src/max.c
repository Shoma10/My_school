#include <stdio.h>

int max(int a, int b);

int main() {
  int a, b;
  char c;

  if ((scanf("%d %d", &a, &b) == 2) &&
      ((scanf("%c", &c) == 1) && (c == '\n'))) {
    int z = max(a, b);
    printf("%d", z);
  } else {
    printf("n/a");
    return 0;
  }
  return 0;
}
int max(int a, int b) {
  int m = a;
  if (b > a)
    m = b;
  return m;
}
