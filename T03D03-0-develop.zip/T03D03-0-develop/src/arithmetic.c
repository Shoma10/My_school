#include <stdio.h>

int main() {
  int a;
  int b;
  char c;
  if (scanf("%d %d%c", &a, &b, &c) != 3 || (int)c != '\n') {
    printf("n/a");
    return 0;
  }
  int sum, diff, mul, quot;
  if (b != 0) {
    sum = a + b;
    diff = a - b;
    mul = a * b;
    quot = a / b;
    printf("%d %d %d %d", sum, diff, mul, quot);
  } else {
    sum = a + b;
    diff = a - b;
    mul = a * b;
    printf("%d %d %d n/a", sum, diff, mul);
  }
  return 0;
}
