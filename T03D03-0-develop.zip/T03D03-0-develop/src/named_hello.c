#include <stdio.h>
int main(void) {
  int name;
  scanf("%d", &name);
  printf("Hello, %d!", name);
  return 0;
}
