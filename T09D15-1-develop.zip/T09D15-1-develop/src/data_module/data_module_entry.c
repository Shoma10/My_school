#include "./../data_libs/data_io.h"
#include "data_process.h"

void main() {
    int n;

    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("n/a");
    } else {
        double *data = malloc((n) * sizeof(double));  // Don`t forget to allocate memory !
        if (data != NULL) {
            input(data, n);

            if (normalization(data, n))
                output(data, n);
            else
                printf("ERROR");
        } else
            printf("n/a");
        free(data);
    }
}
