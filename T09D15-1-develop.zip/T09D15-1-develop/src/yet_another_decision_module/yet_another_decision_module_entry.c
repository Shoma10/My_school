#include "./../data_libs/data_io.h"
#include "decision.h"

void main() {
    int n;

    if (scanf("%d", &n) != 1) {
        printf("n/a");
    } else {
        double *data = malloc((n) * sizeof(double));
        if (data == NULL) {
            printf("Memory not allocated");
        } else {
            input(data, n);
            if (make_decision(data, n))
                printf("YES");
            else
                printf("NO");
        }
        free(data);
    }
}
