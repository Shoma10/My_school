#include <math.h>

#ifndef SRC_YET_ANOTHER_DECISION_MODULE_DECISION_H_
#define SRC_YET_ANOTHER_DECISION_MODULE_DECISION_H_

#define GOLDEN_RATIO 0.666


int make_decision(double *data, int n);

#endif







            
