read -p "Enter the filename: " filename
if [[ -e $filename && -s $filename ]];
then
    sums=`wc -l $filename | awk '{print $1}'`
    uniqs=`cut -d " " -f 1 $filename | sort -u | wc -l`
    changes=`cut -d " " -f 8 $filename | sort -u | wc -l`
    echo "$sums" "$uniqs" "$changes"
else
    echo "File is empty"
fi
