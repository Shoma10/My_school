read -p "Enter filename: " filename
read -p "Enter the search string: " search
read -p "Enter the replace string: " replace
if [[ $search != "" && $replace != "" ]];
then
    sed -i "" "s/$search/$replace/" $filename
fi

filesize=$(stat -f%z $filename)
shasum=$(shasum -a 256 $filename | cut -d " " -f 1)
dateTime=$(stat -f "%Sm" -t"%Y-%m-%d %H:%M" $filename)
echo "$filename - $filesize - $dateTime -$shasum - sha256" >> files.log
