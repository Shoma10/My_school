#include <math.h>
#include <stdio.h>
int rem(int x, int y);
int prost(int n);
int main() {
    int a, b;
    scanf("%d", &a);
    if (a>2){
    for (int z = a-1; z--;){
        int qw = rem(a, z);
        if (qw == 0){
            int c = prost(z); 
            if (c==2){
                printf("%d", z);
                break;
            }
        }
        }
    } else
        printf("n/a");
    return 0;
}

int rem(int x, int y) {
  while (x >= y) {
    x -= y;
  }
  return x;
}
int prost(int n){
    int res = 0, count = 0, x;
    for (int i = 1; i <= n, i++;){
        x = n;
        while (x>= i){
            res++;
            x-= i;
        }
        if (x==0) count++;
    }
    return count;
}
