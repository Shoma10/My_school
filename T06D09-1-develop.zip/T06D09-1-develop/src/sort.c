#include <stdio.h>
#define NMAX 10

int input(int *a);
void output(int *a);
void sort(int *a);
void swap(int *i, int *j);

int main() {
    int data[NMAX];
    if (input(data) == 0) {
        sort(data);
        output(data);
    } else {
        printf("n/a");
    }
}

int input(int *a) {
    for (int i = 0; i < NMAX; i++) {
        if (scanf("%d", &a[i]) != 1) return 1;
    }
    return 0;
}

void output(int *a) {
    for (int i = 0; i < NMAX; i++) {
        printf("%d ", a[i]);
    }
}

void swap(int *i, int *j) {
    int temp = *i;
    *i = *j;
    *j = temp;
}

void sort(int *a) {
    for (int i = 0; i < NMAX - 1; i++) {
        for (int j = 0; j < NMAX - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                swap(a + j, a + j + 1);
            }
        }
    }
}
