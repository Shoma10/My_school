#include <stdio.h>
#include <stdlib.h>
#include <termios.h>
#include <unistd.h>

#define COLUMNS 80
#define ROWS 25

int read_files(int data[][COLUMNS]);
void print_field(int data[][COLUMNS]);
void game_logic(int data[][COLUMNS], int *cell);
int is_alive();
void start_game(int data[][COLUMNS], int *speed, int *cell);

int main() {
    int data[ROWS][COLUMNS];
    int cell = 1;
    int speed = 200000;
    read_files(data);
    start_game(data, &speed, &cell);

    return 0;
}

void start_game(int data[][COLUMNS], int *speed, int *cell) {
    while (*cell) {
        struct termios term;
        fd_set rfds;
        struct timeval tv;
        char c;
        tv.tv_sec = 0;
        tv.tv_usec = 0;
        game_logic(data, cell);
        usleep(*speed);
        print_field(data);

        tcgetattr(STDIN_FILENO, &term);
        term.c_lflag &= ~(ICANON | ECHO);
        tcsetattr(0, TCSANOW, &term);

        while (1) {
            FD_ZERO(&rfds);
            FD_SET(0, &rfds);
            int retval = select(2, &rfds, NULL, NULL, &tv);
            if (retval) {
                c = getchar();
                if ((c == 'Z' || c == 'z') && *speed < 500000) *speed = *speed + 10000;
                if ((c == 'A' || c == 'a') && *speed > 10000) *speed -= 10000;
                if (c == 'Q' || c == 'q') {
                    exit(EXIT_FAILURE);
                }
            } else {
                printf("\033[0d\033[2J");
                break;
            }
        }
    }
}

void game_logic(int data[][COLUMNS], int *cell) {
    int count_cell = 0;
    int new_data[ROWS][COLUMNS];
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLUMNS; j++) {
            new_data[i][j] = is_alive(data, i, j);
            if (new_data[i][j]) count_cell++;
        }
    }
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLUMNS; j++) {
            data[i][j] = new_data[i][j];
        }
    }

    *cell = count_cell;
}

int read_files(int data[][COLUMNS]) {
    printf("Нажмите цифру от 1 до 5 чтобы запустить игру: ");
    char menu = getchar();
    FILE *file;
    int flag = 1;
    switch (menu) {
        case '1':
            file = fopen("matrix1.txt", "r");
            break;
        case '2':
            file = fopen("matrix2.txt", "r");
            break;
        case '3':
            file = fopen("matrix3.txt", "r");
            break;
        case '4':
            file = fopen("matrix4.txt", "r");
            break;
        case '5':
            file = fopen("matrix5.txt", "r");
            break;
        default:
            printf("Введён неверный номер! ");
    }
    if (file != NULL) {
        for (int i = 0; i <= ROWS; i++) {
            for (int j = 0; j < COLUMNS; j++) {
                fscanf(file, "%d", &data[i][j]);
            }
        }
    } else
        flag = 0;
    return flag;
}

int is_alive(int data[][COLUMNS], int line, int column) {
    int flag = 0;
    int alive_around = 0;

    for (int i = line - 1; i <= line + 1; i++) {
        for (int j = column - 1; j <= column + 1; j++) {
            if (data[(i + ROWS) % ROWS][(j + COLUMNS) % COLUMNS]) {
                if (i == line && j == column) continue;
                alive_around++;
            }
        }
    }

    if ((alive_around == 2 || alive_around == 3) && data[line][column]) {
        flag = 1;
    } else if (alive_around == 3 && !data[line][column]) {
        flag = 1;
    }
    return flag;
}

void print_field(int data[][COLUMNS]) {
    printf(
        "                         A для повышения скорости. \n                "
        "         Z для понижения "
        "скорости. \n                         Q для выхода из игры. \n");
    for (int i = 0; i < ROWS; i++) {
        for (int j = 0; j < COLUMNS; j++) {
            if (data[i][j] == 1)
                printf("*");
            else if (data[i][j] == 0)
                printf(" ");
        }
        printf("\n");
    }
}
