#ifndef SRC_CIPHER_H_
#define SRC_CIPHER_H_
#include <dirent.h>
#include <string.h>

void dir_open_and_encr(char *dir_path, int key);
void encrypt(char *filepath, char *filename, int key);
void file_write(char *filepath, char *filename);
const char *get_filename(const char *filename);
int is_empty(char *filename);
int write_file(char *filename);
int open_output(char *filename);
void encript(char *filename, char *filepath, int key);
char caesar(char character, int key);
int nol(FILE *open);

#endif
