#include "cipher.h"

#include <stdio.h>
#define NMAX 10000

int main() {
    int flag = 1, mode, key;
    char filename[NMAX], dir_path[NMAX];
    while (flag) {
        scanf("%d", &mode);
        if (mode == 1) {
            scanf("%s", filename);
            if (is_empty(filename) == 1 || open_output(filename) == 1) {
                //                    char ch = getc(stdin);
                //                    while (ch != EOF && ch != '\n') {
                //                    ch = getc(stdin);
                //                    }
                printf("n/a\n");
            }
        } else if (mode == 2) {
            if (write_file(filename) == 1) {
                char ch = getc(stdin);
                while (ch != EOF && ch != '\n') {
                    ch = getc(stdin);
                }
                printf("n/a\n");
            }
            open_output(filename);
        } else if (mode == 3) {
            scanf("%s", dir_path);
            scanf("%d", &key);
            dir_open_and_encr(dir_path, key);
        } else if (mode == -1) {
            flag = 0;
        } else {
            char c = getc(stdin);
            while (c != EOF && c != '\n') {
                c = getc(stdin);
            }
            printf("n/a\n");
        }
    }
}

void dir_open_and_encr(char *dir_path, int key) {
    char temp_test[NMAX];
    DIR *directory;
    struct dirent *dir;
    directory = opendir(dir_path);
    for (int i = 0; i < NMAX; i++) temp_test[i] = dir_path[i];
    while ((dir = readdir(directory)) != NULL) {
        encrypt(dir_path, dir->d_name, key);
        for (int i = 0; i < NMAX; i++) dir_path[i] = temp_test[i];
    }
    closedir(directory);
}

void encrypt(char *filepath, char *filename, int key) {
    if ((strncmp((get_filename(filename)), "c", 1)) == 0) {
        encript(filename, filepath, key);
    } else if ((strncmp((get_filename(filename)), "h", 1)) == 0) {
        file_write(filepath, filename);
    }
}

void file_write(char *filepath, char *filename) {
    FILE *file_to_open;
    file_to_open = fopen(strcat(filepath, filename), "w");
    fclose(file_to_open);
}

const char *get_filename(const char *filename) {
    const char *dot = strrchr(filename, '.');
    if (!dot || dot == filename) return "";
    return dot + 1;
}

int is_empty(char *filename) {
    FILE *file_to_open;
    file_to_open = fopen(filename, "r");
    if (file_to_open != NULL) {
        int size;
        fseek(file_to_open, 0, SEEK_END);
        size = ftell(file_to_open);
        if (size == 0) {
            fclose(file_to_open);
            return 1;
        }
    }
    return 0;
}

int write_file(char *filename) {
    char /*string_to_add[NMAX], */ word;
    word = getchar();
    FILE *file_to_open;
    file_to_open = fopen(filename, "r");
    if (file_to_open == NULL) {
        return 1;
    }
    file_to_open = fopen(filename, "a");
    for (int i = 0; (word = getchar()) != '\n'; i++) {
        //       string_to_add[i] = word;
        fprintf(file_to_open, "%c", word);
    }
    fclose(file_to_open);
    return 0;
}

int open_output(char *filename) {
    FILE *file_to_open;
    char string_to_output;
    file_to_open = fopen(filename, "r");
    if ((file_to_open == NULL) || (nol(file_to_open) == 1)) {
        return 1;
    }
    string_to_output = fgetc(file_to_open);
    while (string_to_output != EOF) {
        printf("%c", string_to_output);
        string_to_output = fgetc(file_to_open);
    }
    fclose(file_to_open);
    printf("\n");
    return 0;
}

void encript(char *filename, char *filepath, int key) {
    char ch;
    int i = 0;
    FILE *file_to_open;
    file_to_open = fopen(strcat(filepath, filename), "r+");
    ch = fgetc(file_to_open);
    while (ch != EOF) {
        fseek(file_to_open, i, SEEK_SET);
        fprintf(file_to_open, "%c", caesar(ch, key));
        ch = fgetc(file_to_open);
        i++;
    }
}

char caesar(char character, int key) {
    if (character <= 90 && character >= 65) {
        return (character - 65 + key) % 26 + 65;
    } else if (character <= 122 && character >= 97) {
        return (character - 97 + key) % 26 + 97;
    } else {
        return character;
    }
}

int nol(FILE *open) {
    fseek(open, 0L, SEEK_END);
    int z = ftell(open);
    if (z == 0) {
        return 1;
    }
    rewind(open);
    return 0;
}
