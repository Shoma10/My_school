#include <stdio.h>
#include <stdlib.h>
#define aSize 100

int input_method(int *method);
int input_size(int *x, int *y);
// int static_m(int *x_e, int *y_e, int input_size_x, int input_size_y);
void first_d(int input_size_x, int input_size_y);
void second_d(int input_size_x, int input_size_y);
void third_d(int input_size_x, int input_size_y);
void input(int **matrix, int a, int b);
void output(int **a, int input_size_x, int input_size_y);
int stat(int a[][aSize], int *input_size_x, int *input_size_y);
void output_stat(int a[][aSize], int n, int m);
int sizeCorrectStat(int s);

int main() {
    int staticMas[aSize][aSize];
    int input_m, input_size_x, input_size_y;  // x_e, y_e;
    input_method(&input_m);
    if (input_m <= 4 && input_m > 0) {
        input_size(&input_size_x, &input_size_y);
        if (input_size_x <= 100 && input_size_y <= 100 && input_size_x > 0 && input_size_y > 0) {
            if (input_m == 1) {
                // if (scanf("%d", &staticMas[aSize][aSize])) {
                stat(staticMas, &input_size_x, &input_size_y);
                output_stat(staticMas, input_size_x, input_size_y);
            } else if (input_m == 2) {
                first_d(input_size_x, input_size_y);
            } else if (input_m == 3) {
                second_d(input_size_x, input_size_y);
            } else if (input_m == 4) {
                third_d(input_size_x, input_size_y);
            } else
                printf("n/a");
        } else
            printf("n/a");
        //} else printf("n/a");
    } else
        printf("n/a");
}

int sizeCorrectStat(int s) { return s > 0 && s < aSize ? 1 : 0; }

int input_method(int *method) {
    scanf("%d", method);
    return *method;
}

int input_size(int *x, int *y) {
    scanf("%d %d", x, y);
    return 0;
}
int stat(int a[][aSize], int *input_size_x, int *input_size_y) {
    int e;
    // if (scanf("%d %d", input_size_x, input_size_y) == 2 && sizeCorrectStat(*input_size_x) &&
    // sizeCorrectStat(*input_size_y)) {
    for (int i = 0; i < *input_size_x; i++) {
        for (int j = 0; j < *input_size_y; j++) {
            if (scanf("%d", &e)) {
                a[i][j] = e;
            } else {
                printf("n/a");
                // flag = 0;
                break;
            }
        }
    }
    //} else {
    //  flag = 0;
    return 0;
}

void output_stat(int a[][aSize], int n, int m) {
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < m; j++) {
            if (j != m - 1)
                printf("%d ", a[i][j]);
            else
                printf("%d", a[i][j]);
        }
        if (i != n - 1) printf("\n");
    }
}

// int static_m(int *x_e, int *y_e, int input_size_x, int input_size_y){
//     int x = 0;
//     int y = 0;
//     int a[input_size_x][input_size_y];
//     for (x = 0; x <= input_size_x - 1; x++){
//         scanf("%d", &x_e[x]);
//         a[x][y] = x_e[x];
//         printf("%d ", a[x][y]);
//         for (y = 0; y <input_size_y - 1; y++){
//             scanf("%d", &y_e[y]);
//             a[x][y] = y_e[y];
//             printf("%d", a[x][y]);
//             if (y < input_size_y - 2) {
//                 printf(" ");
//             }
//         }
//         if (x <= input_size_x - 2) {
//             printf("\n");
//         }
//     }
// }

void input(int **matrix, int input_size_x, int input_size_y) {
    for (int i = 0; i < input_size_x; i++) {
        for (int j = 0; j < input_size_y; j++) {
            scanf("%d", &matrix[i][j]);
        }
    }
}

void output(int **a, int input_size_x, int input_size_y) {
    for (int i = 0; i < input_size_x; i++) {
        for (int j = 0; j < input_size_y; j++) {
            if (j != input_size_y - 1)
                printf("%d ", a[i][j]);
            else
                printf("%d", a[i][j]);
        }
        printf("\n");
    }
    printf("\b");
}

void first_d(int input_size_x, int input_size_y) {
    int **matrix = malloc(input_size_x * input_size_y * sizeof(int) + input_size_x * sizeof(int *));
    int *ptr = (int *)(matrix + input_size_x);
    for (int i = 0; i < input_size_x; i++) {
        matrix[i] = ptr + input_size_y * i;
    }
    input(matrix, input_size_x, input_size_y);
    output(matrix, input_size_x, input_size_y);
    printf("\b");
    free(matrix);
}

void second_d(int input_size_x, int input_size_y) {
    int **matrix = malloc(input_size_x * sizeof(int *));
    for (int i = 0; i < input_size_x; i++) {
        matrix[i] = malloc(input_size_x * sizeof(int *));
    }
    input(matrix, input_size_x, input_size_y);
    output(matrix, input_size_x, input_size_y);
    printf("\b");
    free(matrix);
}

void third_d(int input_size_x, int input_size_y) {
    int **matrix = malloc(input_size_x * sizeof(int *));
    int *val = malloc(input_size_x * input_size_y * sizeof(int));
    for (int i = 0; i < input_size_x; i++) {
        matrix[i] = val + input_size_y * i;
    }
    input(matrix, input_size_x, input_size_y);
    output(matrix, input_size_x, input_size_y);
    printf("\b");
    free(matrix);
    free(val);
}
