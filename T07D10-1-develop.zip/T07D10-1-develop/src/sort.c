#include <stdio.h>
#include <stdlib.h>

//какая должна быть проверка на ноль?

int input(int *a, int n);
void output(int *a, int n);
void sort(int *a, int n);
void swap(int *i, int *j);
void length();
int input_n(int *n);

int main() {
    int num;
    if (input_n(&num) > 0) {
        int *data = (int *)malloc(sizeof(int) * num);
        if (data != NULL) {
            if (input(data, num) == 0) {
                sort(data, num);
                output(data, num);
            } else {
                printf("n/a");
            }
        } else {
            printf("n/a");
            free(data);
        }
        free(data);
    } else {
        printf("n/a");
    }
}

int input_n(int *n) {
    int flag = 0;
    if (scanf("%d", n)) {
        flag = *n;
    } else {
        flag = 0;
    }
    return flag;
}

int input(int *a, int n) {
    int flag = 0;
    for (int i = 0; i < n; i++) {
        if (scanf("%d", &a[i]) != 1) flag = 1;
    }
    flag = 0;
    return flag;
}

void output(int *a, int n) {
    for (int i = 0; i < n; i++) {
        printf("%d ", a[i]);
    }
}

void swap(int *i, int *j) {
    int temp = *i;
    *i = *j;
    *j = temp;
}

void sort(int *a, int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (a[j] > a[j + 1]) {
                swap(a + j, a + j + 1);
            }
        }
    }
}
