mv door_managememt_fi door_management_files
mkdir door_configuration
mkdir door_logs
mkdir door_map
mv *.conf door_configuration
mv .log door_logs
mv door_map_1.1 door_map
chmod 777 ai_door_control.sh

